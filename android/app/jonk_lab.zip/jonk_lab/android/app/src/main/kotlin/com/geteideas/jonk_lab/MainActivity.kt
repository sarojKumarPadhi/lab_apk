package com.geteideas.jonk_lab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}
