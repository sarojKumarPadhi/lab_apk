import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class MapView extends StatefulWidget {
  @override
  _MapViewState createState() => _MapViewState();
}

class _MapViewState extends State<MapView> {
  late BitmapDescriptor customIcon;

  Future<void> loadCustomIcon() async {
    customIcon = await BitmapDescriptor.fromAssetImage(
      ImageConfiguration(devicePixelRatio: 2.5), // Adjust the devicePixelRatio as needed
      'assets/images/custom_marker.png', // Path to your marker image
    );
  }
  late GoogleMapController _controller;
  Set<Marker> _markers = Set();

  List<LatLng> latLen = [
    LatLng(30.6611,76.8822),
    LatLng(30.6544, 76.8791),
    LatLng(30.6747, 76.8634),
  ];
  @override
  void initState() {
    super.initState();
    loadCustomIcon();
    for(int i=0; i<latLen.length; i++){
      _markers.add(
        // added markers
          Marker(
            markerId: MarkerId(i.toString()),
            position: latLen[i],
            infoWindow: InfoWindow(
              title: 'HOTEL',
              snippet: '5 Star Hotel',
            ),
            icon: customIcon,
          )
      );
      setState(() {

      });

    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GoogleMap(
        onMapCreated: (controller) {
          _controller = controller;
        },
        initialCameraPosition: CameraPosition(
          target: LatLng(30.6544, 76.8791), // Replace with your desired location
          zoom: 14.0,
        ),
        markers: _markers,
      ),
    );
  }
}